class Player {
    String nom;
    int score;
    int vie;
    int tour;
}