#!/bin/sh
javac -cp lib/program.jar:. GenerateurSite.java